function afficherDisciplines() {
    var tabCoutAdm = [0, 888.50, 955.76, 523.89, 843.17];
    var tabDisciplineAdm = ["Choisir une discipline", "Gestion", "Comtabilite", "Economie", "Informatique"];
    var tabCoutMed = [0, 1789.45, 2345.12, 2645.12, 2534.34, 2645.12, 3402.34];
    var tabDisciplineMed = ["Choisir une discipline", "Medecine generale", "Gynecologie", "Oncologie", "Pediatrie", "Urologie", "Orthopedie"];
    var indexSelectionne = document.formPaiementEtudiant.cboDepartement.selectedIndex;
    var cboDiscipline = document.formPaiementEtudiant.cboDiscipline;
    if (indexSelectionne == 1) { //sciences adminstratives
        cboDiscipline.options.length = tabDisciplineAdm.length;
        for (var i = 0; i < tabDisciplineAdm.length; i++) {
            cboDiscipline.options[i].text = tabDisciplineAdm[i];
            cboDiscipline.options[i].value = "" + tabCoutAdm[i];
        } //for
    } //if
    else if (indexSelectionne == 2) {
        cboDiscipline.options.length = tabDisciplineMed.length;
        for (var i = 0; i < tabDisciplineMed.length; i++) {
            cboDiscipline.options[i].text = tabDisciplineMed[i];
            cboDiscipline.options[i].value = "" + tabCoutMed[i];
        } //for
    } //if
    else if (indexSelectionne == 0) {
        cboDiscipline.options.length = 1;
        cboDiscipline.options[0].text = "Choisir une discipline";
        cboDiscipline.options[0].value = "0";
    }

} //fin afficherDislines

function afficherEtudiants() {
    var tabEtudiantGestion = ["Choisir un etudiant", "Pierre Andre", "Etienne Millien"];
    var tabEtudiantComtabilite = ["Choisir un etudiant", "Robin Mireille", "Douracher Erica"];
    var tabEtudiantEconomie = ["Choisir un etudiant", "Raafat Yakob", "Robert Yakob"];
    var tabEtudiantInformatique = ["Choisir un etudiant", "Raafat Yakob", "Robert Yakob", "Romario Yakob"];
    var tabEtudiantOrthopedie = ["Choisir un etudiant", "Nicolase Judith", "Aurilien Jessica", "Mohamede Ali", "Amera Saed", "Omar Elmasry"];
    var indexDepSelectionne = document.formPaiementEtudiant.cboDepartement.selectedIndex;
    var indexDiscSellectionne = document.formPaiementEtudiant.cboDiscipline.selectedIndex;
    var cboEtudiant = document.formPaiementEtudiant.cboEtudiant;

    if (indexDepSelectionne == 1 && indexDiscSellectionne == 1) { //Gestion
        cboEtudiant.options.length = tabEtudiantGestion.length;
        for (var i = 0; i < tabEtudiantGestion.length; i++) {
            cboEtudiant.options[i].text = tabEtudiantGestion[i];
        } //for
    } //if
    if (indexDepSelectionne == 1 && indexDiscSellectionne == 2) { //Comtabilite
        cboEtudiant.options.length = tabEtudiantComtabilite.length;
        for (var i = 0; i < tabEtudiantComtabilite.length; i++) {
            cboEtudiant.options[i].text = tabEtudiantComtabilite[i];
        } //for
    } //if
    if (indexDepSelectionne == 1 && indexDiscSellectionne == 3) { //Economie
        cboEtudiant.options.length = tabEtudiantEconomie.length;
        for (var i = 0; i < tabEtudiantEconomie.length; i++) {
            cboEtudiant.options[i].text = tabEtudiantEconomie[i];
        } //for
    } //if
    if (indexDepSelectionne == 1 && indexDiscSellectionne == 4) { //Informatique
        cboEtudiant.options.length = tabEtudiantInformatique.length;
        for (var i = 0; i < tabEtudiantInformatique.length; i++) {
            cboEtudiant.options[i].text = tabEtudiantInformatique[i];
        } //for
    } //if
    else {
        cboEtudiant.options.length = tabEtudiantOrthopedie.length;
        for (var i = 0; i < tabEtudiantOrthopedie.length; i++) {
            cboEtudiant.options[i].text = tabEtudiantOrthopedie[i];
        } //for
    }
    var coutSession = document.formPaiementEtudiant.cboDiscipline.options[indexDiscSellectionne].value;
    document.getElementById("idCoutSession").innerHTML = coutSession;

} //fin afficherEtudiants

function activerPaiement() {
    var indexSelectionne = document.formPaiementEtudiant.cboEtudiant.selectedIndex;
    if (indexSelectionne > 0) {
        document.formPaiementEtudiant.txtPaiement.disabled = false;
    } //fin if
    else {
        document.formPaiementEtudiant.txtPaiement.disabled = true;
        document.formPaiementEtudiant.txtPaiement.value = "";

    } //fin else
} //fin activerPaiement

function calculerSolde() {
    var textMontantPaiement = document.formPaiementEtudiant.txtPaiement.value;
    var montantPaiement = parseFloat(textMontantPaiement);
    var textCoutSession = document.getElementById("idCoutSession").innerHTML;
    var coutSession = parseFloat(textCoutSession);
    var solde = coutSession - montantPaiement;
    document.getElementById("idSolde").innerHTML = solde.toFixed(2);
} //fin Calc Solde

function afficherFacture(solde) {
    calculerSolde();
} //Fin function afficherFacture