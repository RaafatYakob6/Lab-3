function ajouter(){
    var photo = document.forms["formulaire"].elements["txtPhoto"].files[0].name;
    var elementImg = document.createElement("img");
    elementImg.setAttribute("src",photo);
    var elementDiv = document.getElementById("idZoneAffichage");
    elementDiv.appendChild(elementImg);
}