var elementActif;

function selectionnerProduit(elementTr) {
    var listeTd = elementTr.getElementsByTagName("td");
    document.formulaire.txtProduit.value = listeTd[0].innerHTML;
    document.formulaire.txtQuantite.value = listeTd[1].innerHTML;
    document.formulaire.txtPrix.value = listeTd[2].innerHTML;
    elementActif = elementTr;
    document.formulaire.txtProduit.disabled = false;
    document.formulaire.txtQuantite.disabled = false;
    document.formulaire.txtPrix.disabled = false;
    document.formulaire.btnModifier.disabled = false;
}

function modifier() {
    var produit = document.formulaire.txtProduit.value;
    var qty = document.formulaire.txtQuantite.value;
    var prix = document.formulaire.txtPrix.value;
    var listeTd = elementActif.getElementsByTagName("td");
    listeTd[0].innerHTML = produit;
    listeTd[1].innerHTML = qty;
    listeTd[2].innerHTML = prix;
    elementActif = undefined;
    nettoyer();
}

function nettoyer() {
    document.formulaire.txtProduit.value = "";
    document.formulaire.txtQuantite.value = "";
    document.formulaire.txtPrix.value = "";
    document.formulaire.txtProduit.disabled = true;
    document.formulaire.txtQuantite.disabled = true;
    document.formulaire.txtPrix.disabled = true;
    document.formulaire.btnModifier.disabled = true;
}

function supprimer(ligne){
    ligne.parentNode.removeChild(ligne);
}