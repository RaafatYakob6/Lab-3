function ajouter() {
    document.getElementById("idTableau").style.display= "block";
    var cboproduit = document.forms["formCalculMontantTotal"].elements["Produit"];
    var indexselection = cboproduit.selectedIndex;
    var nomProduit = cboproduit.options[indexselection].text;
    var composantprix = document.getElementById("idprix");
    var prixProduit = parseFloat(composantprix.innerHTML);
    var quantite = document.forms["formCalculMontantTotal"].elements["txtQuantite"].value;
    if (quantite == "") {
        alert("Il faut saisir une valeur pour la quantite");
        return;
    }
    quantite = parseInt(quantite);
    if (isNaN(quantite)) {
        alert("la quantite doit etre un nombre");
        return;
    }
    //
    var noeudTr = document.createElement("tr");
    var noeudTd1 = document.createElement("td");
    var contenuTd1 = document.createTextNode(nomProduit);
    noeudTd1.appendChild(contenuTd1);
    noeudTr.appendChild(noeudTd1);
    
    var noeudTd2 = document.createElement("td");
    var contenuTd2 = document.createTextNode("" + prixProduit);
    noeudTd2.appendChild(contenuTd2);
    noeudTr.appendChild(noeudTd2);
    
    var noeudTd3 = document.createElement("td");
    var contenuTd3 = document.createTextNode("" + quantite);
    noeudTd3.appendChild(contenuTd3);
    noeudTr.appendChild(noeudTd3);

    var elementTBody = document.getElementById("idContenuTableau");
    elementTBody.appendChild(noeudTr);

}

function afficherTotal() {
    var listeTr = document.getElementsByTagName("tr");
    var total = 0;
    for (var i = 1; i < listeTr.length; i++) {
        var ligne = listeTr[i];
        var tabTd = ligne.getElementsByTagName("td");
        var prix = parseFloat(tabTd[1].innerHTML);
        var quantite = parseInt(tabTd[2].innerHTML);
        var sousTotal = prix * quantite;
        total += sousTotal;
    } //for
    var elementTotal = document.getElementById("idTotal");
    elementTotal.innerHTML = total + "$";
} //fin function afficher Total

function afficherprix() {
    var cboproduit = document.forms["formCalculMontantTotal"].elements["Produit"];
    var indexselection = cboproduit.selectedIndex;
    var Prix = cboproduit.options[indexselection].value;
    var composantprix = document.getElementById("idprix");
    composantprix.innerHTML = Prix;
}